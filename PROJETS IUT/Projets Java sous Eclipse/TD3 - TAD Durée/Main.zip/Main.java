import java.util.Scanner ;

public class Main {

	public static void main(String[] args) {
		// lire les 2 dur�es
		Scanner entr�e = new Scanner(System.in) ;
		System.out.println("saisir la premi�re dur�e (heures minutes secondes) : ") ;
		int h = entr�e.nextInt() ;
		int m = entr�e.nextInt() ;
		int s = entr�e.nextInt() ;
		Dur�e d1 = new Dur�eEnSecondes(h, m, s) ;
		System.out.println("saisir la deuxi�me dur�e (heures minutes secondes) : ");
		h = entr�e.nextInt() ;
		m = entr�e.nextInt() ;
		s = entr�e.nextInt() ;
		Dur�e d2 = new Dur�eEnSecondes(h, m, s) ;
		entr�e.close() ;

		// permuter les 2 dur�es si la premi�re est plus petite que la seconde
		if (d1.inf(d2)) {
			Dur�e aux = d1 ;
			d1 = d2 ;
			d2 = aux ;
		}
		System.out.println("premi�re dur�e : " + d1) ;
		System.out.println("deuxi�me dur�e : " + d2) ;

		// calculer la dur�e s�parant 2 dur�es sachant que d1 est la plus grande des 2
		// � compl�ter
		
	}		

}
